SEWA BARANG - proyek aplikasi Android (WebView)

Isi:
- app/src/main/assets/index.html  = seluruh aplikasi (tampilan dan logika)
- app/src/main/assets/fonts       = font bawaan (jalan tanpa internet)
- sewa.keystore                   = kunci penanda tangan APK (jangan diganti,
                                    agar update menimpa aplikasi lama tanpa
                                    menghapus data)

Cara pakai di GitHub:
1. Unggah proyek.zip ke root repo (tanpa diekstrak).
2. Buat file .github/workflows/proyek.yml, isi dengan berkas proyek.yml.
3. Buka tab Actions, tunggu build selesai.
4. Unduh SewaBarang.apk dari menu Releases di repo.
